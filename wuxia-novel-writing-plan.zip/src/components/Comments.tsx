"use client";

import { useCallback, useEffect, useState } from "react";

type Comment = { id: number; nickname: string; content: string; createdAt: string };

export default function Comments({ chapterNo }: { chapterNo: number }) {
  const [list, setList] = useState<Comment[]>([]);
  const [nickname, setNickname] = useState("");
  const [content, setContent] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const load = useCallback(async () => {
    try {
      const r = await fetch(`/api/comments?chapter=${chapterNo}`, { cache: "no-store" });
      const j = await r.json();
      setList(j.comments ?? []);
    } catch {
      setList([]);
    }
  }, [chapterNo]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
    setNickname(localStorage.getItem("jx:nick") ?? "");
  }, [load]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    if (!content.trim()) return setErr("写点什么再发吧");
    setBusy(true);
    try {
      const r = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chapterNo, nickname, content }),
      });
      if (!r.ok) throw new Error((await r.json()).error ?? "发送失败");
      localStorage.setItem("jx:nick", nickname);
      setContent("");
      await load();
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : "发送失败");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mt-12">
      <h2 className="mb-4 text-xl font-bold">
        <span className="mr-2 text-[var(--cinnabar)]">▍</span>本章书评（{list.length}）
      </h2>
      <form onSubmit={submit} className="card space-y-3 p-4">
        <input
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          maxLength={20}
          placeholder="江湖名号（可不填）"
          className="w-full rounded border border-[var(--line)] bg-transparent px-3 py-2 text-sm outline-none focus:border-[var(--cinnabar)]"
        />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          maxLength={500}
          rows={3}
          placeholder="说说你对这一章的看法，或者猜猜后面的剧情……"
          className="w-full rounded border border-[var(--line)] bg-transparent px-3 py-2 text-sm outline-none focus:border-[var(--cinnabar)]"
        />
        <div className="flex items-center justify-between">
          <span className="text-xs text-[var(--cinnabar)]">{err}</span>
          <button disabled={busy} className="seal px-5 py-2 text-sm disabled:opacity-50">
            {busy ? "发送中…" : "留言"}
          </button>
        </div>
      </form>
      <ul className="mt-4 space-y-3">
        {list.map((c) => (
          <li key={c.id} className="card p-4">
            <div className="flex items-baseline justify-between text-xs text-[var(--ink-soft)]">
              <span className="font-bold text-[var(--ink)]">{c.nickname}</span>
              <time>{new Date(c.createdAt).toLocaleString("zh-CN")}</time>
            </div>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-7">{c.content}</p>
          </li>
        ))}
        {list.length === 0 && <li className="py-4 text-center text-sm text-[var(--ink-soft)]">还没有人留言，来做第一个读者吧。</li>}
      </ul>
    </section>
  );
}
