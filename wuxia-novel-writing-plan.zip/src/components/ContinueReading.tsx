"use client";

import Link from "next/link";
import { useSyncExternalStore } from "react";

function subscribe(cb: () => void) {
  window.addEventListener("storage", cb);
  return () => window.removeEventListener("storage", cb);
}

export default function ContinueReading() {
  const last = useSyncExternalStore(
    subscribe,
    () => localStorage.getItem("jx:lastChapter"),
    () => null,
  );
  if (!last || last === "1") return null;
  return (
    <Link href={`/read/${last}`} className="card px-6 py-3 text-sm transition hover:border-[var(--cinnabar)]">
      继续阅读 · 第{last}章
    </Link>
  );
}
