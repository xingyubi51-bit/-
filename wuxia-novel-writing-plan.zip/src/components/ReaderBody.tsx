"use client";

import { useEffect, useState } from "react";

export default function ReaderBody({ no, title, paragraphs }: { no: number; title: string; paragraphs: string[] }) {
  const [size, setSize] = useState(19);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    localStorage.setItem("jx:lastChapter", String(no));
    const s = Number(localStorage.getItem("jx:size"));
    const d = localStorage.getItem("jx:dark") === "1";
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (s >= 15 && s <= 28) setSize(s);
    setDark(d);
  }, [no]);

  const change = (n: number) => {
    const v = Math.min(28, Math.max(15, size + n));
    setSize(v);
    localStorage.setItem("jx:size", String(v));
  };
  const toggle = () => {
    setDark(!dark);
    localStorage.setItem("jx:dark", !dark ? "1" : "0");
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-end gap-2 text-xs">
        <button onClick={() => change(-1)} className="card px-3 py-1.5 hover:border-[var(--cinnabar)]">
          A−
        </button>
        <span className="w-8 text-center text-[var(--ink-soft)]">{size}</span>
        <button onClick={() => change(1)} className="card px-3 py-1.5 hover:border-[var(--cinnabar)]">
          A+
        </button>
        <button onClick={toggle} className="card px-3 py-1.5 hover:border-[var(--cinnabar)]">
          {dark ? "日间" : "夜间"}
        </button>
      </div>
      <article className={`reader rounded-md px-5 py-10 sm:px-12 ${dark ? "dark-mode" : "card"}`} style={{ fontSize: size, lineHeight: 2 }}>
        <h1 className="mb-10 text-center text-3xl font-black tracking-widest" style={{ fontSize: size + 10 }}>
          <span className="mb-2 block text-xs font-normal tracking-[0.3em] opacity-60">第 {no} 章</span>
          {title}
        </h1>
        {paragraphs.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
        <div className="mt-10 text-center text-sm opacity-50">— 本章完 —</div>
      </article>
    </div>
  );
}
