import ch01 from "./ch01";
import ch02 from "./ch02";
import ch03 from "./ch03";
import ch04 from "./ch04";
import ch05 from "./ch05";

export type Chapter = { no: number; title: string; volume: number; body: string };

export const chapters: Chapter[] = [ch01, ch02, ch03, ch04, ch05];

export function getChapter(no: number) {
  return chapters.find((c) => c.no === no);
}

export function wordCount(text: string) {
  return text.replace(/\s/g, "").length;
}
