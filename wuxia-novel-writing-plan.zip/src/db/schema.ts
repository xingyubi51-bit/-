import { integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  chapterNo: integer("chapter_no").notNull(),
  nickname: varchar("nickname", { length: 30 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
