import Link from "next/link";
import { book, world } from "@/content/book";
import { characters } from "@/content/characters";
import { chapters, wordCount } from "@/content/chapters";
import { volumes } from "@/content/outline";
import ContinueReading from "@/components/ContinueReading";

export default function Home() {
  const total = chapters.reduce((s, c) => s + wordCount(c.body), 0);
  const heroines = characters.filter((c) => c.role === "heroine");
  const latest = [...chapters].reverse().slice(0, 5);

  return (
    <div className="mx-auto max-w-5xl px-5">
      <section className="py-16 text-center sm:py-24">
        <p className="mb-4 text-xs tracking-[0.4em] text-[var(--ink-soft)]">{book.genre}</p>
        <h1 className="text-6xl font-black tracking-[0.3em] sm:text-8xl">
          烬<span className="text-[var(--cinnabar)]">雪</span>江湖
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-[var(--ink-soft)]">{book.subtitle}</p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link href="/read/1" className="seal px-7 py-3 text-base transition hover:opacity-90">
            开始阅读
          </Link>
          <ContinueReading />
          <Link href="/outline" className="card px-6 py-3 text-sm transition hover:border-[var(--cinnabar)]">
            查看大纲
          </Link>
        </div>
        <div className="mx-auto mt-10 grid max-w-2xl grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          {[
            ["计划体量", "250 万字"],
            ["全书规模", "10 卷 · 1000 章"],
            ["已更正文", `${chapters.length} 章 · ${(total / 10000).toFixed(1)} 万字`],
            ["女主", `${heroines.length} 位`],
          ].map(([k, v]) => (
            <div key={k} className="card px-3 py-3">
              <div className="text-xs text-[var(--ink-soft)]">{k}</div>
              <div className="mt-1 font-bold">{v}</div>
            </div>
          ))}
        </div>
      </section>

      <div className="divider" />

      <section className="grid gap-10 py-14 md:grid-cols-5">
        <div className="md:col-span-3">
          <h2 className="mb-5 text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>内容简介
          </h2>
          <div className="space-y-4 leading-8 text-[15px]">
            {book.synopsis.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </div>
        <div className="md:col-span-2">
          <h2 className="mb-5 text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>全书立意
          </h2>
          <ul className="space-y-3 text-sm leading-7 text-[var(--ink-soft)]">
            {book.themes.map((t, i) => (
              <li key={i} className="card p-4">
                {t}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <div className="divider" />

      <section className="py-14">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>她们
          </h2>
          <Link href="/characters" className="text-sm text-[var(--cinnabar)] hover:underline">
            全部人物设定 →
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {heroines.map((h) => (
            <Link key={h.id} href={`/characters#${h.id}`} className="card group p-4 transition hover:-translate-y-0.5 hover:border-[var(--cinnabar)]">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full text-lg font-bold text-white" style={{ background: h.color }}>
                  {h.name[0]}
                </span>
                <div>
                  <div className="font-bold">{h.name}</div>
                  <div className="text-xs text-[var(--ink-soft)]">{h.alias}</div>
                </div>
              </div>
              <div className="mt-3 text-xs leading-5 text-[var(--ink-soft)]">{h.faction}</div>
            </Link>
          ))}
        </div>
      </section>

      <div className="divider" />

      <section className="grid gap-10 py-14 md:grid-cols-2">
        <div>
          <h2 className="mb-5 text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>最新章节
          </h2>
          <ul className="card divide-y divide-[var(--line)]">
            {latest.map((c) => (
              <li key={c.no}>
                <Link href={`/read/${c.no}`} className="flex items-center justify-between px-4 py-3 transition hover:bg-[var(--paper-deep)]">
                  <span>
                    <span className="mr-3 text-xs text-[var(--ink-soft)]">第{c.no}章</span>
                    {c.title}
                  </span>
                  <span className="text-xs text-[var(--ink-soft)]">{wordCount(c.body)} 字</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="mb-5 text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>十卷总览
          </h2>
          <ol className="space-y-2 text-sm">
            {volumes.map((v) => (
              <li key={v.no} className="flex items-baseline gap-3">
                <span className="w-12 shrink-0 text-xs text-[var(--ink-soft)]">第{v.no}卷</span>
                <span className="font-bold">{v.title}</span>
                <span className="text-xs text-[var(--ink-soft)]">{v.heroines[0].replace(/（.*?）/g, "")}</span>
              </li>
            ))}
          </ol>
          <p className="mt-5 text-xs leading-6 text-[var(--ink-soft)]">背景：{world.era}</p>
        </div>
      </section>
    </div>
  );
}
