import Link from "next/link";
import { chapters, wordCount } from "@/content/chapters";
import { volumes } from "@/content/outline";

export const metadata = { title: "目录 · 烬雪江湖" };

export default function ChaptersPage() {
  return (
    <div className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="text-4xl font-black tracking-widest">目录</h1>
      <p className="mt-3 text-sm text-[var(--ink-soft)]">已更 {chapters.length} 章，后续章节按大纲持续创作。</p>

      <div className="mt-10 space-y-10">
        {volumes.map((v) => {
          const list = chapters.filter((c) => c.volume === v.no);
          return (
            <section key={v.no}>
              <div className="mb-3 flex items-baseline gap-3 border-b border-[var(--line)] pb-2">
                <span className="seal px-2 py-0.5 text-xs">第{v.no}卷</span>
                <h2 className="text-xl font-bold">{v.title}</h2>
                <span className="text-xs text-[var(--ink-soft)]">{v.range}</span>
              </div>
              {list.length === 0 ? (
                <p className="py-3 text-sm text-[var(--ink-soft)]">尚未开笔 · {v.hook}</p>
              ) : (
                <ul className="grid gap-x-6 sm:grid-cols-2">
                  {list.map((c) => (
                    <li key={c.no}>
                      <Link href={`/read/${c.no}`} className="flex justify-between border-b border-dashed border-[var(--line)] py-3 transition hover:text-[var(--cinnabar)]">
                        <span>
                          <span className="mr-3 text-xs text-[var(--ink-soft)]">第{c.no}章</span>
                          {c.title}
                        </span>
                        <span className="text-xs text-[var(--ink-soft)]">{wordCount(c.body)}字</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
