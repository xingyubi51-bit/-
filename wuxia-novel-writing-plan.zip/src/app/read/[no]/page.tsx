import Link from "next/link";
import { notFound } from "next/navigation";
import { chapters, getChapter } from "@/content/chapters";
import ReaderBody from "@/components/ReaderBody";
import Comments from "@/components/Comments";

export function generateStaticParams() {
  return chapters.map((c) => ({ no: String(c.no) }));
}

export async function generateMetadata({ params }: { params: Promise<{ no: string }> }) {
  const { no } = await params;
  const c = getChapter(Number(no));
  return { title: c ? `第${c.no}章 ${c.title} · 烬雪江湖` : "烬雪江湖" };
}

export default async function ReadPage({ params }: { params: Promise<{ no: string }> }) {
  const { no } = await params;
  const n = Number(no);
  const chapter = getChapter(n);
  if (!chapter) notFound();

  const prev = getChapter(n - 1);
  const next = getChapter(n + 1);
  const paragraphs = chapter.body.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);

  const nav = (
    <div className="my-8 flex items-center justify-between gap-3 text-sm">
      {prev ? (
        <Link href={`/read/${prev.no}`} className="card px-5 py-2.5 transition hover:border-[var(--cinnabar)]">
          ← 上一章
        </Link>
      ) : (
        <span className="px-5 py-2.5 text-[var(--ink-soft)]/50">← 上一章</span>
      )}
      <Link href="/chapters" className="text-[var(--ink-soft)] hover:text-[var(--cinnabar)]">
        目录
      </Link>
      {next ? (
        <Link href={`/read/${next.no}`} className="seal px-5 py-2.5 transition hover:opacity-90">
          下一章 →
        </Link>
      ) : (
        <span className="px-5 py-2.5 text-[var(--ink-soft)]">待续…</span>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <ReaderBody no={chapter.no} title={chapter.title} paragraphs={paragraphs} />
      {nav}
      {!next && (
        <div className="card p-5 text-center text-sm leading-7 text-[var(--ink-soft)]">
          第{chapter.no + 1}章创作中。可前往<Link href="/outline" className="text-[var(--cinnabar)] hover:underline">大纲</Link>
          查看后续走向。
        </div>
      )}
      <Comments chapterNo={chapter.no} />
    </div>
  );
}
