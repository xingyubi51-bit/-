import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "烬雪江湖 · 多女主武侠长篇",
  description: "250 万字武侠群像长篇《烬雪江湖》——设定、大纲、人物与连载正文。",
};

const nav = [
  { href: "/", label: "首页" },
  { href: "/chapters", label: "目录" },
  { href: "/outline", label: "大纲" },
  { href: "/characters", label: "人物" },
  { href: "/world", label: "世界观" },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">
        <header className="sticky top-0 z-20 border-b border-[var(--line)] bg-[var(--paper)]/90 backdrop-blur">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
            <Link href="/" className="flex items-center gap-2">
              <span className="seal h-8 w-8 text-lg">烬</span>
              <span className="text-lg font-bold tracking-widest">烬雪江湖</span>
            </Link>
            <nav className="flex gap-4 text-sm sm:gap-6">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} className="text-[var(--ink-soft)] transition hover:text-[var(--cinnabar)]">
                  {n.label}
                </Link>
              ))}
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="mt-20 border-t border-[var(--line)] py-8 text-center text-xs text-[var(--ink-soft)]">
          《烬雪江湖》 · 原创武侠长篇 · 铁，急了会断；人，也一样。
        </footer>
      </body>
    </html>
  );
}
