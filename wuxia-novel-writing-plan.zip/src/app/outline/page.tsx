import { structure, volumes, principles, nextPlan } from "@/content/outline";

export const metadata = { title: "大纲 · 烬雪江湖" };

export default function OutlinePage() {
  return (
    <div className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-4xl font-black tracking-widest">全书大纲</h1>
      <p className="mt-3 text-sm text-[var(--ink-soft)]">十卷 · 一千章 · 二百五十万字。三幕结构，每卷一位主女主。</p>

      <section className="mt-10 grid gap-4 md:grid-cols-3">
        {structure.map((s) => (
          <div key={s.name} className="card p-5">
            <h3 className="font-bold text-[var(--cinnabar)]">{s.name}</h3>
            <p className="mt-2 text-sm leading-7 text-[var(--ink-soft)]">{s.desc}</p>
          </div>
        ))}
      </section>

      <h2 className="mb-5 mt-14 text-2xl font-bold">
        <span className="mr-2 text-[var(--cinnabar)]">▍</span>十卷卷纲
      </h2>
      <div className="space-y-3">
        {volumes.map((v) => (
          <details key={v.no} open={v.no === 1} className="card group p-5">
            <summary className="flex cursor-pointer list-none flex-wrap items-baseline gap-3">
              <span className="seal px-2 py-0.5 text-xs">第{v.no}卷</span>
              <span className="text-xl font-bold">{v.title}</span>
              <span className="text-xs text-[var(--ink-soft)]">
                {v.range} · {v.words}
              </span>
              <span className="ml-auto text-xs text-[var(--ink-soft)] group-open:hidden">展开 ▾</span>
            </summary>
            <div className="mt-4 space-y-4 text-sm leading-7">
              <div className="flex flex-wrap gap-2">
                {v.heroines.map((h) => (
                  <span key={h} className="chip">
                    {h}
                  </span>
                ))}
              </div>
              <p>{v.synopsis}</p>
              <div>
                <div className="mb-1 font-bold">关键情节</div>
                <ul className="list-disc space-y-1.5 pl-5 text-[var(--ink-soft)]">
                  {v.beats.map((b, i) => (
                    <li key={i}>{b}</li>
                  ))}
                </ul>
              </div>
              <p>
                <b className="text-[var(--cinnabar)]">高潮：</b>
                {v.climax}
              </p>
              <p>
                <b className="text-[var(--cinnabar)]">卷末钩子：</b>
                {v.hook}
              </p>
            </div>
          </details>
        ))}
      </div>

      <h2 className="mb-5 mt-14 text-2xl font-bold">
        <span className="mr-2 text-[var(--cinnabar)]">▍</span>创作原则
      </h2>
      <ol className="card list-decimal space-y-3 p-6 pl-10 text-sm leading-7">
        {principles.map((p, i) => (
          <li key={i}>{p}</li>
        ))}
      </ol>

      <h2 className="mb-5 mt-14 text-2xl font-bold">
        <span className="mr-2 text-[var(--cinnabar)]">▍</span>接下来的写作计划
      </h2>
      <ul className="card divide-y divide-[var(--line)] text-sm">
        {nextPlan.map((n) => (
          <li key={n.range} className="flex gap-4 px-5 py-3">
            <span className="w-24 shrink-0 font-bold">{n.range}</span>
            <span className="text-[var(--ink-soft)]">{n.note}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
