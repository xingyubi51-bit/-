import { characters, roleLabel, type Character } from "@/content/characters";

export const metadata = { title: "人物设定 · 烬雪江湖" };

function Field({ k, v }: { k: string; v: string }) {
  if (!v || v === "—") return null;
  return (
    <div>
      <dt className="text-xs font-bold tracking-widest text-[var(--cinnabar)]">{k}</dt>
      <dd className="mt-1 text-sm leading-7">{v}</dd>
    </div>
  );
}

function Card({ c }: { c: Character }) {
  return (
    <article id={c.id} className="card scroll-mt-24 overflow-hidden">
      <div className="flex items-center gap-4 border-b border-[var(--line)] p-5" style={{ borderLeft: `6px solid ${c.color}` }}>
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full text-2xl font-black text-white" style={{ background: c.color }}>
          {c.name[0]}
        </span>
        <div className="min-w-0">
          <div className="flex flex-wrap items-baseline gap-2">
            <h3 className="text-2xl font-black tracking-wide">{c.name}</h3>
            <span className="text-sm text-[var(--ink-soft)]">「{c.alias}」</span>
          </div>
          <div className="mt-1 flex flex-wrap gap-2">
            <span className="chip">{roleLabel[c.role]}</span>
            <span className="chip">{c.faction}</span>
            <span className="chip">{c.age} 岁</span>
            <span className="chip">首次登场：{c.debut}</span>
          </div>
        </div>
      </div>
      <dl className="grid gap-4 p-5 md:grid-cols-2">
        <Field k="外貌" v={c.look} />
        <Field k="性格" v={c.personality} />
        <Field k="武学" v={c.skill} />
        <Field k="兵器" v={c.weapon} />
        <Field k="身世" v={c.background} />
        <Field k="秘密 ⚠ 剧透" v={c.secret} />
        <Field k="成长弧" v={c.arc} />
        <Field k="与沈砚" v={c.bond} />
      </dl>
      <div className="border-t border-[var(--line)] bg-[var(--paper-deep)]/60 px-5 py-3 text-sm italic text-[var(--ink-soft)]">{c.line}</div>
    </article>
  );
}

export default function CharactersPage() {
  const groups: { title: string; role: Character["role"] }[] = [
    { title: "男主", role: "male" },
    { title: "女主群像", role: "heroine" },
    { title: "重要配角", role: "support" },
    { title: "反派", role: "villain" },
  ];
  return (
    <div className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-4xl font-black tracking-widest">人物设定</h1>
      <p className="mt-3 text-sm text-[var(--ink-soft)]">八位女主，来自八个势力；每个人都有自己的债、自己的剑、自己的江湖。</p>

      <nav className="mt-6 flex flex-wrap gap-2">
        {characters.map((c) => (
          <a key={c.id} href={`#${c.id}`} className="chip transition hover:border-[var(--cinnabar)] hover:text-[var(--cinnabar)]">
            {c.name}
          </a>
        ))}
      </nav>

      {groups.map((g) => (
        <section key={g.role} className="mt-12">
          <h2 className="mb-5 text-2xl font-bold">
            <span className="mr-2 text-[var(--cinnabar)]">▍</span>
            {g.title}
          </h2>
          <div className="space-y-6">
            {characters
              .filter((c) => c.role === g.role)
              .map((c) => (
                <Card key={c.id} c={c} />
              ))}
          </div>
        </section>
      ))}
    </div>
  );
}
