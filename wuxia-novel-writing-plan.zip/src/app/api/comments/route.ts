import { db } from "@/db";
import { comments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const chapter = Number(new URL(req.url).searchParams.get("chapter"));
  if (!Number.isInteger(chapter) || chapter < 1) {
    return Response.json({ comments: [] });
  }
  try {
    const rows = await db
      .select()
      .from(comments)
      .where(eq(comments.chapterNo, chapter))
      .orderBy(desc(comments.createdAt))
      .limit(100);
    return Response.json({ comments: rows });
  } catch {
    return Response.json({ comments: [], error: "db" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  let body: { chapterNo?: unknown; nickname?: unknown; content?: unknown };
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "请求格式错误" }, { status: 400 });
  }
  const chapterNo = Number(body.chapterNo);
  const content = typeof body.content === "string" ? body.content.trim() : "";
  const nickname = (typeof body.nickname === "string" ? body.nickname.trim() : "").slice(0, 20) || "无名过客";
  if (!Number.isInteger(chapterNo) || chapterNo < 1) {
    return Response.json({ error: "章节不存在" }, { status: 400 });
  }
  if (!content || content.length > 500) {
    return Response.json({ error: "留言需在 1–500 字之间" }, { status: 400 });
  }
  try {
    const [row] = await db.insert(comments).values({ chapterNo, nickname, content }).returning();
    return Response.json({ comment: row }, { status: 201 });
  } catch {
    return Response.json({ error: "服务器开小差了" }, { status: 500 });
  }
}
