import { world } from "@/content/book";

export const metadata = { title: "世界观 · 烬雪江湖" };

const H = ({ children }: { children: React.ReactNode }) => (
  <h2 className="mb-5 mt-14 text-2xl font-bold">
    <span className="mr-2 text-[var(--cinnabar)]">▍</span>
    {children}
  </h2>
);

export default function WorldPage() {
  return (
    <div className="mx-auto max-w-4xl px-5 py-12">
      <h1 className="text-4xl font-black tracking-widest">世界观</h1>
      <p className="mt-4 text-sm leading-7 text-[var(--ink-soft)]">{world.era}</p>

      <H>势力谱</H>
      <div className="grid gap-4 sm:grid-cols-2">
        {world.factions.map((f) => (
          <div key={f.name} className="card p-5">
            <div className="flex items-baseline justify-between">
              <h3 className="text-lg font-bold">{f.name}</h3>
              <span className="chip">{f.tag}</span>
            </div>
            <p className="mt-1 text-xs text-[var(--cinnabar)]">{f.style}</p>
            <p className="mt-3 text-sm leading-7">{f.desc}</p>
            <p className="mt-3 text-xs text-[var(--ink-soft)]">代表女主：{f.heroine}</p>
          </div>
        ))}
      </div>

      <H>武学体系</H>
      <p className="mb-4 text-sm leading-7">{world.powerSystem.intro}</p>
      <ol className="card divide-y divide-[var(--line)]">
        {world.powerSystem.realms.map((r, i) => (
          <li key={r.name} className="flex gap-4 px-5 py-3 text-sm">
            <span className="seal h-6 w-6 shrink-0 text-xs">{i + 1}</span>
            <span className="w-12 shrink-0 font-bold">{r.name}</span>
            <span className="text-[var(--ink-soft)]">{r.desc}</span>
          </li>
        ))}
      </ol>
      <p className="mt-4 text-sm leading-7">
        <b className="text-[var(--cinnabar)]">特殊规则：</b>
        {world.powerSystem.uniqueRule}
      </p>

      <H>地理</H>
      <ul className="grid gap-3 sm:grid-cols-2">
        {world.geography.map((g) => (
          <li key={g.name} className="card p-4">
            <div className="font-bold">{g.name}</div>
            <p className="mt-1 text-sm leading-6 text-[var(--ink-soft)]">{g.desc}</p>
          </li>
        ))}
      </ul>

      <H>大事年表</H>
      <ol className="relative ml-2 space-y-6 border-l border-[var(--line)] pl-6">
        {world.timeline.map((t) => (
          <li key={t.year} className="relative">
            <span className="absolute -left-[31px] top-1.5 h-2.5 w-2.5 rounded-full bg-[var(--cinnabar)]" />
            <div className="text-sm font-bold">{t.year}</div>
            <p className="mt-1 text-sm leading-7 text-[var(--ink-soft)]">{t.event}</p>
          </li>
        ))}
      </ol>

      <H>伏笔清单（作者备忘）</H>
      <ul className="card list-disc space-y-2 p-6 pl-10 text-sm leading-7">
        {world.foreshadows.map((f, i) => (
          <li key={i}>{f}</li>
        ))}
      </ul>
    </div>
  );
}
